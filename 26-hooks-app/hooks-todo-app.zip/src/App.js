import React from "react";
import TodoApp from "./TodoApp";

function App() {
  return <TodoApp />;
}

export default App;
