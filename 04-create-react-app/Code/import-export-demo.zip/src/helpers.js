function helpful() {
	console.log('I DID A SUPER HELPFUL THING');
}

function sort() {
	console.log('ALL SORTED!');
}

function sing() {
	console.log('LA LA LA');
}

export default helpful;
export { sort, sing };
