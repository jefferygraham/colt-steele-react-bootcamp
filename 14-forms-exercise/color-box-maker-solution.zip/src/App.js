import React, { Component } from "react";
import BoxList from "./BoxList";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div>
        <BoxList />
      </div>
    );
  }
}

export default App;
