import React, { Component } from "react";
import IconList from "./IconList";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div className='App'>
        <IconList />
      </div>
    );
  }
}

export default App;
