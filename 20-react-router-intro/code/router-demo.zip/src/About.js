import React, { Component } from "react";

class About extends Component {
  render() {
    return (
      <div className='About'>
        <h1>About!!!</h1>
        <p>This is the about page...</p>
      </div>
    );
  }
}
export default About;
